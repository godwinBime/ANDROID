package com.example.customedittext;

public class EditTextWithClear extends android.support.v7.widget.AppCompatEditText {
}
